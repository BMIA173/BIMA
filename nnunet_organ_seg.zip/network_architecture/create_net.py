# from nnunet.network_architecture.neural_network import SegmentationNetwork
from torch import nn
from nnunet.network_architecture.neural_network import SegmentationNetwork
from nnunet.network_architecture.UNet3D_self import UNet3D
from nnunet.network_architecture.unet_3D import unet_3D
from nnunet.network_architecture.vnet_1 import VNet
from nnunet.network_architecture.attention_unet import Attention_UNet
import torch
import torch.nn.functional as F
import pdb
from monai.networks.nets import SwinUNETR
from nnunet.network_architecture.unetr import UNETR
from monai.networks.nets import UNet
def softmax_helper(x): return F.softmax(x, 1)

class custom_net(SegmentationNetwork):

    def __init__(self, num_classes):
        super(custom_net, self).__init__()
        self.params = {'content': None}
        self.conv_op = nn.Conv3d
        self.do_ds = True
        self.num_classes = num_classes

        ######## self.model 设置自定义网络 by Sleeep ########
        # self.model = UNet(in_chns=1,class_num=num_classes)
        # self.model = UNet3D(1,num_classes)
        # self.model = unet_3D(feature_scale=2, n_classes=55, in_channels=1)
        # self.model = Attention_UNet(feature_scale=2, n_classes=55,in_channels=1)
        # self.model = VNet(55)
        #self.model = SwinUNETR(
        #    img_size=(96, 96, 96),
        #    in_channels=1,
        #    out_channels=105,
        #    feature_size=60,
        #    drop_rate=0.0,
        #    attn_drop_rate=0.0,
        #    dropout_path_rate=0.0,
        #    use_checkpoint=False,
        #)
        self.model =UNet(
        spatial_dims=3,
        in_channels=1,
        out_channels=105,
        channels=(4, 8, 16, 32, 64),
        strides=(2, 2, 2, 2),
        )
        #self.model = UNETR(
        #    in_channels=1,
        #    out_channels=105,
        #    img_size=(128, 128, 128),
        #    feature_size=48,
        #    hidden_size=768,
        #    mlp_dim=3072,
        #    num_heads=12,
        #    pos_embed="perceptron",
        #    norm_name="instance",
        #    conv_block=True,
        #    res_block=True,
        #    dropout_rate=0.0,
        #)
        ######## self.model 设置自定义网络 by Sleeep ########

        # self.name = self.model.name

    def forward(self, x):

        if self.do_ds:
            return tuple([self.model(x)])
        else:
            return self.model(x)


def create_model(num_classes):

    return custom_net(num_classes)


'''
def initialize_network():
    """
    - momentum 0.99
    - SGD instead of Adam
    - self.lr_scheduler = None because we do poly_lr
    - deep supervision = True
    - i am sure I forgot something here
    Known issue: forgot to set neg_slope=0 in InitWeights_He; should not make a difference though
    :return:
    """
    # if self.threeD:
    #     conv_op = nn.Conv3d
    #     dropout_op = nn.Dropout3d
    #     norm_op = nn.InstanceNorm3d
    #
    # else:
    #     conv_op = nn.Conv2d
    #     dropout_op = nn.Dropout2d
    #     norm_op = nn.InstanceNorm2d
    #
    # norm_op_kwargs = {'eps': 1e-5, 'affine': True}
    # dropout_op_kwargs = {'p': 0, 'inplace': True}
    # net_nonlin = nn.LeakyReLU
    # net_nonlin_kwargs = {'negative_slope': 1e-2, 'inplace': True}
    # self.network = Generic_UNet(self.num_input_channels, self.base_num_features, self.num_classes,
    #                             len(self.net_num_pool_op_kernel_sizes),
    #                             self.conv_per_stage, 2, conv_op, norm_op, norm_op_kwargs, dropout_op,
    #                             dropout_op_kwargs,
    #                             net_nonlin, net_nonlin_kwargs, True, False, lambda x: x, InitWeights_He(1e-2),
    #                             self.net_num_pool_op_kernel_sizes, self.net_conv_kernel_sizes, False, True, True)
    ############## add custom model by Sleeep ##############
    network = create_model()
    ############## add custom model by Sleeep ##############
    if torch.cuda.is_available():
        network.cuda()
    network.inference_apply_nonlin = softmax_helper
    return network

input = torch.FloatTensor(2, 1,32, 64, 64)
input_var = input.cuda()
model = initialize_network()
out = model(input_var)
print(out.size())
'''
