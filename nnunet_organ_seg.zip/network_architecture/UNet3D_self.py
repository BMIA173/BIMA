import torch
import torch.nn as nn
import pdb
import time

class UNet3D(nn.Module):
    def __init__(self, in_channel, n_classes):
        super(UNet3D, self).__init__()

        self.in_channel = in_channel
        self.n_classes = n_classes

        self.ec0 = self.encoder(self.in_channel, 32, bias=True, batchnorm=True)
        self.ec1 = self.encoder(32, 64, bias=True, batchnorm=True)
        self.ec2 = self.encoder(64, 64, bias=True, batchnorm=True)
        self.ec3 = self.encoder(64, 128, bias=True, batchnorm=True)
        self.ec4 = self.encoder(128, 128, bias=True, batchnorm=True)
        self.ec5 = self.encoder(128, 256, bias=True, batchnorm=True)
        self.ec6 = self.encoder(256, 256, bias=True, batchnorm=True)
        self.ec7 = self.encoder(256, 512, bias=True, batchnorm=True)

        self.pool0 = nn.MaxPool3d(2)
        self.pool1 = nn.MaxPool3d(2)
        self.pool2 = nn.MaxPool3d(2)

        self.dc9 = self.decoder(512, 512, kernel_size=2, stride=2, bias=True)
        self.dc8 = self.decoder(256 + 512, 256, kernel_size=3, stride=1, padding=1, bias=True)
        self.dc7 = self.decoder(256, 256, kernel_size=3, stride=1, padding=1, bias=True)
        self.dc6 = self.decoder(256, 256, kernel_size=2, stride=2, bias=True)
        self.dc5 = self.decoder(128 + 256, 128, kernel_size=3, stride=1, padding=1, bias=True)
        self.dc4 = self.decoder(128, 128, kernel_size=3, stride=1, padding=1, bias=True)
        self.dc3 = self.decoder(128, 128, kernel_size=2, stride=2, bias=True)
        self.dc2 = self.decoder(64 + 128, 64, kernel_size=3, stride=1, padding=1, bias=True)
        self.dc1 = self.decoder(64, 64, kernel_size=3, stride=1, padding=1, bias=True)
        self.dc0 = self.decoder(64, n_classes, kernel_size=1, stride=1, bias=True)
        self.i = 0


    def encoder(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1,
                bias=True, batchnorm=False):
        if batchnorm:
            layer = nn.Sequential(
                nn.Conv3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, bias=bias),
                nn.BatchNorm3d(out_channels),
                nn.ReLU())
        else:
            layer = nn.Sequential(
                nn.Conv3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, bias=bias),
                nn.ReLU())
        return layer


    def decoder(self, in_channels, out_channels, kernel_size, stride=1, padding=0,
                output_padding=0, bias=True):
        layer = nn.Sequential(
            nn.ConvTranspose3d(in_channels, out_channels, kernel_size, stride=stride,
                               padding=padding, output_padding=output_padding, bias=bias),
            nn.ReLU())
        return layer

    def forward(self, x):
        self.i = self.i + 1  
        timestamp = time.time()
        time_struct = time.localtime(timestamp)
        current_time = time.strftime('%Y.%m.%d-%H:%M:%S',time_struct)
        print("time1",current_time)
        print("i",self.i)
        x = self.ec0(x)
        syn0 = self.ec1(x)
        x = self.pool0(syn0)
        x = self.ec2(x)
        syn1 = self.ec3(x)

        x = self.pool1(syn1)
        x = self.ec4(x)
        syn2 = self.ec5(x)

        x = self.pool2(syn2)
        x = self.ec6(x)
        x = self.ec7(x)

        x = torch.cat((self.dc9(x), syn2),dim=1)
        x = self.dc8(x)
        x = self.dc7(x)

        x = torch.cat((self.dc6(x), syn1),dim=1)

        x = self.dc5(x)
        x = self.dc4(x)

        x = torch.cat((self.dc3(x), syn0),dim=1)

        x = self.dc2(x)
        x = self.dc1(x)

        seg = self.dc0(x)
        timestamp1 = time.time()
        time_struct1 = time.localtime(timestamp1)
        current_time1 = time.strftime('%Y.%m.%d-%H:%M:%S',time_struct1)
        print("time2",current_time1)
        return seg

'''
if __name__ =='__main__':
    model = UNet3D(1,4)
    x = torch.FloatTensor(2,1,16,64,64)
    result = model(x)
    print(1)
'''
