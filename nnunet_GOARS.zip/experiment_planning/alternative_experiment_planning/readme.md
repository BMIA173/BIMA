These alternatives are not used in nnU-Net, but you can use them if you believe they might be better suited for you. 
I (Fabian) have not found them to be consistently superior.